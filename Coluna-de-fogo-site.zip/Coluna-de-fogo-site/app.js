import { db } from './firebase.js';
import { collection, addDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

window.showPage = function(p) {
  document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
  document.getElementById(p).classList.add('active');
};

window.cadastrarMembro = async function() {
  const nome = document.getElementById('nome').value;
  const email = document.getElementById('email').value;

  if (!nome || !email) {
    document.getElementById('cadastroStatus').innerText = 'Preencha todos os campos.';
    return;
  }

  await addDoc(collection(db, 'membros'), {
    nome,
    email,
    criadoEm: new Date()
  });

  document.getElementById('cadastroStatus').innerText = 'Cadastro enviado!';
};window.toggleMenu = function () {
  const menu = document.getElementById('menu');
  menu.classList.toggle('active');
};function abrirDevocional() {
  alert("Em breve: devocional completo 🙏");
}